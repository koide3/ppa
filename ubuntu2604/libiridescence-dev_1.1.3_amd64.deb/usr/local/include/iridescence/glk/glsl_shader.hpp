#ifndef GLK_GLSL_SHADER_HPP
#define GLK_GLSL_SHADER_HPP

#include <thread>
#include <vector>
#include <memory>
#include <string>
#include <iostream>
#include <optional>
#include <variant>
#include <unordered_set>
#include <unordered_map>

#include <GL/gl3w.h>
#include <Eigen/Core>
#include <glk/hash.hpp>
#include <glk/make_shared.hpp>

namespace glk {

/// @brief GLSLShader is a wrapper for OpenGL shader programs.
/// @details
/// Building a shader program
/// --- Option 1: From source files ---
/// auto shader = std::make_shared<glk::GLSLShader>();
/// shader->attach_source("vertex_shader.glsl", GL_VERTEX_SHADER);
/// shader->attach_source("fragment_shader.glsl", GL_FRAGMENT_SHADER);
/// shader->link_program();
/// --- Option 2: From source files ---
/// std::string vs_source = "...";  // Vertex shader source code
/// std::string fs_source = "...";  // Fragment shader source code
/// shader->attach_source(vs_source, GL_VERTEX_SHADER);
/// shader->attach_source(fs_source, GL_FRAGMENT_SHADER);
/// shader->link_program();
///
/// Getting attribute and uniform locations
/// ---
/// shader->use();
/// GLint position_loc = shader->attrib("position");
/// GLint color_loc = shader->attrib("color");
/// GLint model_matrix_loc = shader->uniform("model_matrix");
/// shader->unuse();
/// ---
///
/// Copying (cached) uniform variables from another shader
/// ---
/// src_shader->copy_cached_uniforms(dst_shader);
/// ---
class GLSLShader {
public:
  GLSLShader();
  ~GLSLShader();

  bool attach_source(const std::string& filename, GLuint shader_type);
  bool attach_source(const std::vector<std::string>& filenames, GLuint shader_type);

  bool attach_source(const std::string& filename, const std::unordered_set<std::string>& include_filenames, const std::string& defines, GLuint shader_type);
  bool attach_source(const std::vector<std::string>& filenames, const std::unordered_set<std::string>& include_filenames, const std::string& defines, GLuint shader_type);

  bool attach_source(
    const std::string& filename,
    const std::unordered_set<std::string>& include_filenames,
    const std::string& defines,
    const std::vector<std::pair<std::string, std::string>>& replaces,
    GLuint shader_type);

  /// @brief Attach shader source code from multiple files, with optional include files, defines, and replacements.
  /// @param filenames          Filenames of the shader source files to attach.
  /// @param include_filenames  Filenames of the include files to be inserted into the shader source code.
  /// @param defines            Preprocessor definitions to be added to the shader source code.
  /// @param replaces           Pairs of strings representing text replacements to be made in the shader source code.
  /// @param shader_type        Type of shader (e.g., GL_VERTEX_SHADER, GL_FRAGMENT_SHADER).
  /// @return                   True if all shader source files were successfully attached, false otherwise.
  bool attach_source(
    const std::vector<std::string>& filenames,
    const std::unordered_set<std::string>& include_filenames,
    const std::string& defines,
    const std::vector<std::pair<std::string, std::string>>& replaces,
    GLuint shader_type);

  /// @brief Attach shader source code from a string
  /// @param source_code  Source code text
  /// @param shader_type  Type of shader
  /// @return             True if the shader source code was successfully attached, false otherwise.
  bool attach_source_code(const std::string& source_code, GLuint shader_type);

  bool add_feedback_varying(const std::string& name);

  /// @brief Link attached shaders into a shader program.
  /// @return true if linking is successful, false otherwise.
  bool link_program();

  bool init(const std::string& shader_path);
  bool init(const std::string& vertex_shader_path, const std::string& fragment_shader_path);
  bool init(const std::vector<std::string>& vertex_shader_paths, const std::vector<std::string>& fragment_shader_paths);

  /// @brief Returns shader ID
  GLuint id() const;
  /// @brief Use the shader in the OpenGL context
  void use() const;
  /// @brief Unuse the shader
  void unuse() const;

  GLint attrib(std::uint64_t name, const char* debug_msg = nullptr);
  GLint attrib(const std::string& name);
  GLint uniform(std::uint64_t name, const char* debug_msg = nullptr);
  GLint uniform(const std::string& name);
  GLint subroutine(GLenum shader_type, std::uint64_t name, const char* debug_msg = nullptr);
  GLint subroutine(GLenum shader_type, const std::string& name);
  GLint subroutine_uniform(GLenum shader_type, std::uint64_t name, const char* debug_msg = nullptr);
  GLint subroutine_uniform(GLenum shader_type, const std::string& name);

  int get_uniformi(std::uint64_t name);
  int get_uniformi(const std::string& name);

  float get_uniformf(std::uint64_t name);
  float get_uniformf(const std::string& name);

  Eigen::Vector4f get_uniform4f(std::uint64_t name);
  Eigen::Vector4f get_uniform4f(const std::string& name);

  Eigen::Matrix4f get_uniform_matrix4f(std::uint64_t name);
  Eigen::Matrix4f get_uniform_matrix4f(const std::string& name);

  void copy_cached_uniforms(GLSLShader& other) const;

  template <typename T>
  T get_uniform_cache(std::uint64_t name) const {
    const auto found = std::find_if(uniform_variable_cache.begin(), uniform_variable_cache.end(), [=](const auto& pair) { return pair.first == name; });
    if (found == uniform_variable_cache.end()) {
      std::cerr << "warning: failed to find uniform variable cache " << name << std::endl;
      return T();
    }

    return std::get<T>(found->second);
  }

  template <typename T>
  std::optional<T> get_uniform_cache_safe(std::uint64_t name) const {
    const auto found = std::find_if(uniform_variable_cache.begin(), uniform_variable_cache.end(), [=](const auto& pair) { return pair.first == name; });
    if (found == uniform_variable_cache.end()) {
      return std::nullopt;
    }

    auto value = std::get_if<T>(&found->second);
    return value ? std::optional<T>(*value) : std::nullopt;
  }

  // int
  void set_uniform(std::uint64_t name, int value, const char* debug_msg = nullptr);
  void set_uniform(const std::string& name, int value);

  // float
  void set_uniform(std::uint64_t name, float value, const char* debug_msg = nullptr);
  void set_uniform(const std::string& name, float value);

  // vec2f
  void set_uniform(std::uint64_t name, const Eigen::Vector2f& vector, const char* debug_msg = nullptr);
  void set_uniform(const std::string& name, const Eigen::Vector2f& vector);

  // vec3f
  void set_uniform(std::uint64_t name, const Eigen::Vector3f& vector, const char* debug_msg = nullptr);
  void set_uniform(const std::string& name, const Eigen::Vector3f& vector);

  // vec4f
  void set_uniform(std::uint64_t name, const Eigen::Vector4f& vector, const char* debug_msg = nullptr);
  void set_uniform(const std::string& name, const Eigen::Vector4f& vector);

  // vec2i
  void set_uniform(std::uint64_t name, const Eigen::Vector2i& vector, const char* debug_msg = nullptr);
  void set_uniform(const std::string& name, const Eigen::Vector2i& vector);

  // vec3i
  void set_uniform(std::uint64_t name, const Eigen::Vector3i& vector, const char* debug_msg = nullptr);
  void set_uniform(const std::string& name, const Eigen::Vector3i& vector);

  // vec4i
  void set_uniform(std::uint64_t name, const Eigen::Vector4i& vector, const char* debug_msg = nullptr);
  void set_uniform(const std::string& name, const Eigen::Vector4i& vector);

  // matrix4f
  void set_uniform(std::uint64_t name, const Eigen::Matrix4f& matrix, const char* debug_msg = nullptr);
  void set_uniform(const std::string& name, const Eigen::Matrix4f& matrix);

  // array of int
  void set_uniform(std::uint64_t name, const std::vector<int>& vectors, const char* debug_msg = nullptr);
  void set_uniform(const std::string& name, const std::vector<int>& vectors);

  // array of float
  void set_uniform(std::uint64_t name, const std::vector<float>& vectors, const char* debug_msg = nullptr);
  void set_uniform(const std::string& name, const std::vector<float>& vectors);

  // array of vec2f
  void set_uniform(std::uint64_t name, const std::vector<Eigen::Vector2f>& vectors, const char* debug_msg = nullptr);
  void set_uniform(const std::string& name, const std::vector<Eigen::Vector2f>& vectors);

  // array of vec3f
  void set_uniform(std::uint64_t name, const std::vector<Eigen::Vector3f>& vectors, const char* debug_msg = nullptr);
  void set_uniform(const std::string& name, const std::vector<Eigen::Vector3f>& vectors);

  // array of vec4f
  void set_uniform(std::uint64_t name, const std::vector<Eigen::Vector4f>& vectors, const char* debug_msg = nullptr);
  void set_uniform(const std::string& name, const std::vector<Eigen::Vector4f>& vectors);
  // matrix4d
  void set_uniform(std::uint64_t name, const Eigen::Matrix4d& matrix_, const char* debug_msg = nullptr);
  void set_uniform(const std::string& name, const Eigen::Matrix4d& matrix_);

  void set_subroutine(GLenum shader_type, const std::string& loc, const std::string& func);

private:
  GLuint create_shader(const std::string& source, GLuint shader_type, const std::string& filename = "");

  GLuint read_shader_from_file(
    const std::string& filename,
    const std::unordered_map<std::string, std::string>& include_map,
    const std::string& defines,
    const std::vector<std::pair<std::string, std::string>>& replaces,
    GLuint shader_type);

  template <typename T>
  void set_uniform_cache(std::uint64_t h, const T& value) {
    auto found = std::find_if(uniform_variable_cache.begin(), uniform_variable_cache.end(), [&h](const auto& pair) { return pair.first == h; });
    if (found != uniform_variable_cache.end()) {
      found->second = value;
    } else {
      uniform_variable_cache.emplace_back(h, value);
    }
  }

private:
  using UniformCacheVariant = std::variant<int, float, Eigen::Vector2f, Eigen::Vector3f, Eigen::Vector4f, Eigen::Vector2i, Eigen::Vector3i, Eigen::Vector4i, Eigen::Matrix4f>;

  std::vector<GLuint> shaders;
  std::vector<std::string> feedback_varyings;

  GLuint shader_program;
  std::vector<std::pair<std::uint64_t, GLint>> attrib_cache;
  std::vector<std::pair<std::uint64_t, GLint>> uniform_cache;

  std::vector<std::pair<std::uint64_t, GLint>> subroutine_cache;
  std::vector<std::pair<std::uint64_t, UniformCacheVariant>> uniform_variable_cache;
};

}  // namespace glk

#endif