#pragma once

#include <spdlog/spdlog.h>

namespace glim {

void print_system_info(std::shared_ptr<spdlog::logger> logger);

}