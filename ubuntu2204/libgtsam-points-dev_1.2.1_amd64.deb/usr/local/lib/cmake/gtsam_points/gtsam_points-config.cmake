# Config file for the gtsam_points package
#
# Usage from an external project:
#
#  find_package(gtsam_points REQUIRED)
#  target_link_libraries(MY_TARGET_NAME gtsam_points::gtsam_points)
#

####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was gtsam_points-config.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include_guard()

set(GTSAM_POINTS_USE_TBB )
set(GTSAM_POINTS_USE_OPENMP 1)
set(GTSAM_POINTS_USE_CUDA )

get_filename_component(gtsam_points_CURRENT_CONFIG_DIR "${CMAKE_CURRENT_LIST_FILE}" PATH)
set(CMAKE_MODULE_PATH ${CMAKE_MODULE_PATH} "${gtsam_points_CURRENT_CONFIG_DIR}")

include(CMakeFindDependencyMacro)
find_dependency(Eigen3 REQUIRED)
find_dependency(GTSAM REQUIRED)
find_dependency(GTSAM_UNSTABLE REQUIRED)
find_dependency(OpenMP REQUIRED)
find_dependency(Boost REQUIRED COMPONENTS filesystem graph)

if(GTSAM_POINTS_USE_TBB)
  find_dependency(TBB REQUIRED)
endif()

if(GTSAM_POINTS_USE_CUDA)
  find_dependency(CUDAToolkit REQUIRED)
endif()

include("${CMAKE_CURRENT_LIST_DIR}/gtsam_points-targets.cmake")
