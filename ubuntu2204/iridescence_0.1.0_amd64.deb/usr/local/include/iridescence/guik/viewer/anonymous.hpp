#ifndef GUIK_ANONYMOUS_HPP
#define GUIK_ANONYMOUS_HPP

#include <string>

namespace guik {

// generate a unique name
std::string anon();

}

#endif