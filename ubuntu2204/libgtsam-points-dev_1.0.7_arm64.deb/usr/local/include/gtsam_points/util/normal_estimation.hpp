// SPDX-License-Identifier: MIT
// Copyright (c) 2025  Kenji Koide (k.koide@aist.go.jp)
#pragma once

// normal_estimation.hpp has been moved to gtsam_points/features
#include <gtsam_points/features/normal_estimation.hpp>