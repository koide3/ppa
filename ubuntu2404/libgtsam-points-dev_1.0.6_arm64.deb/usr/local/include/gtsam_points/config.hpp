// SPDX-License-Identifier: MIT
// Copyright (c) 2021  Kenji Koide (k.koide@aist.go.jp)

#pragma once

// Library version
#define GTSAM_POINTS_VERSION_MAJOR 1
#define GTSAM_POINTS_VERSION_MINOR 0
#define GTSAM_POINTS_VERSION_PATCH 6
#define GTSAM_POINTS_VERSION_STRING "1.0.6"

#define GTSAM_POINTS_GIT_HASH ""

#define GTSAM_POINTS_USE_TBB

#define GTSAM_POINTS_USE_OPENMP

/* #undef GTSAM_POINTS_USE_CUDA */

/* #undef GTSAM_POINTS_WITH_MARCH_NATIVE */
