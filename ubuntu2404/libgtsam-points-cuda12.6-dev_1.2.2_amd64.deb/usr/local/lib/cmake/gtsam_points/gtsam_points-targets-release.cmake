#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "gtsam_points::gtsam_points" for configuration "Release"
set_property(TARGET gtsam_points::gtsam_points APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(gtsam_points::gtsam_points PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libgtsam_points.so.1.2.2"
  IMPORTED_SONAME_RELEASE "libgtsam_points.so.1"
  )

list(APPEND _cmake_import_check_targets gtsam_points::gtsam_points )
list(APPEND _cmake_import_check_files_for_gtsam_points::gtsam_points "${_IMPORT_PREFIX}/lib/libgtsam_points.so.1.2.2" )

# Import target "gtsam_points::gtsam_points_cuda" for configuration "Release"
set_property(TARGET gtsam_points::gtsam_points_cuda APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(gtsam_points::gtsam_points_cuda PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libgtsam_points_cuda.so.1.2.2"
  IMPORTED_SONAME_RELEASE "libgtsam_points_cuda.so.1"
  )

list(APPEND _cmake_import_check_targets gtsam_points::gtsam_points_cuda )
list(APPEND _cmake_import_check_files_for_gtsam_points::gtsam_points_cuda "${_IMPORT_PREFIX}/lib/libgtsam_points_cuda.so.1.2.2" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
